# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts', 'brain_games.scripts.games']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0', 'random2>=1.0.1,<2.0.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.games.brain_calc:main',
                     'brain-even = brain_games.scripts.games.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.games.brain_gcd:main',
                     'brain-prime = brain_games.scripts.games.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.games.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Five logical games',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Exteni/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Exteni/python-project-49/actions)\n<a href="https://codeclimate.com/github/Exteni/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/a160b67193e959c8abd7/maintainability" /></a>\n\nДанный пакет представляет собой набор из 5 логических игр, по 3 раунда в каждой:\n1) Проверка на чётность - необходимо ответить, чётное число или нет. </br>\nВызывается командой brain-even, пример - \n[![asciicast](https://asciinema.org/a/mgmegCY9WPhfgykK5ZONBJ4fZ.svg)](https://asciinema.org/a/mgmegCY9WPhfgykK5ZONBJ4fZ)\n2) Калькулятор - необходимо найти сумму, частное или произведение двух чисел. </br>\nВызывается командой brain-calc, пример - \n[![asciicast](https://asciinema.org/a/Hz1CnPUXxHpbYbN3R6xykvVIt.svg)](https://asciinema.org/a/Hz1CnPUXxHpbYbN3R6xykvVIt)\n3) НОД - необходимо назвать наибольший общий делитель двух чисел. </br>\nВызывается командой brain-gcd, пример - \n[![asciicast](https://asciinema.org/a/QXQ0Nr27uiL3MqhgmsE2utY2d.svg)](https://asciinema.org/a/QXQ0Nr27uiL3MqhgmsE2utY2d)\n4) Арифметическая прогрессия - нужно найти пропущенный элемент арифметической прогрессии. </br>\nВызывается командой brain-progression, пример - \n[![asciicast](https://asciinema.org/a/vhk41qmAlwfdgqvTtKvd9eWlr.svg)](https://asciinema.org/a/vhk41qmAlwfdgqvTtKvd9eWlr)\n5) Простое ли число? - необходимо ответить, простое число или нет. </br>\nВызывается командой brain-prime, пример - \n[![asciicast](https://asciinema.org/a/3HTeNL9ktRk27kCUsZg2fpFSE.svg)](https://asciinema.org/a/3HTeNL9ktRk27kCUsZg2fpFSE)\n',
    'author': 'Grigory Mukhin',
    'author_email': 'extenit@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/Exteni/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
