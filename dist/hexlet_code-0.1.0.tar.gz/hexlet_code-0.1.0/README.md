### Hexlet tests and linter status:
[![Actions Status](https://github.com/Exteni/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Exteni/python-project-49/actions)
<a href="https://codeclimate.com/github/Exteni/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/a160b67193e959c8abd7/maintainability" /></a>

brain-even = https://asciinema.org/a/i8maza0kUHFiU4sn8rz2gipO9
brain-calc = https://asciinema.org/a/9bTobzC9EtKaYBpOurkuGhShh